需要将该环境conda的python与openpose编译,才能调用openpose python API  



