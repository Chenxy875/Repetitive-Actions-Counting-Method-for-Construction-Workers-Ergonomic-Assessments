wget http://guanghan.info/download/Data/LightTrack/dets/DeformConv_FPN_RCNN_detect.zip
wget http://guanghan.info/download/Data/LightTrack/dets/DeformConv_RFCN_detect.zip
wget http://guanghan.info/download/Data/LightTrack/dets/GT_detect.zip

unzip DeformConv_FPN_RCNN_detect.zip
unzip DeformConv_RFCN_detect.zip
unzip GT_detect.zip
