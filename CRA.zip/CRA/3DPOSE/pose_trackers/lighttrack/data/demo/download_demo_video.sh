# download demo video
wget http://guanghan.info/download/Data/LightTrack/demo/video.mp4
