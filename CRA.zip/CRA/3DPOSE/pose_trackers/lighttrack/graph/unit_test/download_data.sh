wget http://guanghan.info/download/Data/LightTrack/weights/gcn_data_train_val.tar.gz
tar xvzf gcn_data_train_val.tar.gz
